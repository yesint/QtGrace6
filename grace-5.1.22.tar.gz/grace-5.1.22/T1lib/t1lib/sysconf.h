#include <config.h>

#define T1LIB_IDENT "1.3.1p3-grace"
#define T1LIB_NO_X11_SUPPORT
